# Contra 2 — Difficulty v9

Trang chơi tĩnh, có ROM/bộ giả lập và bản tải Windows đi kèm. Không cần máy chủ của chủ game.

## Đưa lên GitHub Pages
1. Tạo repository công khai, ví dụ `contra2-difficulty-v9`.
2. Đưa toàn bộ nội dung của gói web lên nhánh `main`, sao cho `index.html` nằm ở thư mục gốc.
3. Mở **Settings → Pages → Build and deployment → Deploy from a branch**.
4. Chọn **main**, thư mục **/(root)**, bấm **Save**.
5. GitHub sẽ cung cấp địa chỉ `https://TEN-TAI-KHOAN.github.io/contra2-difficulty-v9/`.

Không có bước biên dịch hay cài Node.js. `.nojekyll` cần được giữ để phục vụ nguyên các tệp.
Gói web tự chứa ROM, lõi WebAssembly, ngôn ngữ và thư viện; các liên kết bản tải dùng đường dẫn tương đối.

Đọc [hướng dẫn chơi](guide.txt), [giấy phép/mã nguồn](licenses.html).
